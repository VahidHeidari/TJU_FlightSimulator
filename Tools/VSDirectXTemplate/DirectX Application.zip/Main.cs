using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;

using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using Framework;
namespace Main
{
    class MainClass : Form
    {
        public static Device Graphic;
        Microsoft.DirectX.Direct3D.Font font;
        Ground ground;
        Camera cam;
        IndexedNormal spaceship;
        void Init()
        {
            this.Text = "Empty";
            this.ClientSize = new System.Drawing.Size(640, 480);
            this.KeyDown += new KeyEventHandler(MainClass_KeyDown);
            this.MouseMove += new MouseEventHandler(MainClass_MouseMove);
            this.MouseDown += new MouseEventHandler(MainClass_MouseDown);

            PresentParameters pp = new PresentParameters();
            pp.BackBufferFormat = Format.X8R8G8B8;
            pp.AutoDepthStencilFormat = DepthFormat.D24X8;
            pp.EnableAutoDepthStencil = true;
            pp.BackBufferCount = 1;
            pp.Windowed = true;
            pp.SwapEffect = SwapEffect.Discard;
            pp.BackBufferWidth = 640;
            pp.BackBufferHeight = 480;

            Graphic = new Device(0, DeviceType.Hardware, this, CreateFlags.HardwareVertexProcessing, pp);
            Graphic.RenderState.ZBufferEnable = true;
            Graphic.RenderState.CullMode = Cull.CounterClockwise;
            Graphic.RenderState.Lighting = false;
            Graphic.DeviceResizing += new System.ComponentModel.CancelEventHandler(Graphic_DeviceResizing);

            //Graphic.RenderState.FillMode = FillMode.WireFrame;
			SetupLights();
        }

        void InitGeometry()
        {
            spaceship = new IndexedNormal("..\\..\\spaceship.txt", "..\\..\\spaceship.bmp");
            ground = new Ground(10, 10, Color.Red.ToArgb());
            cam = new Camera();
            cam.Position = new Vector3(0, 5, -5);

            font = new Microsoft.DirectX.Direct3D.Font(Graphic, new System.Drawing.Font("lucida console", 10, FontStyle.Bold));
        }

		void SetupLights()
        {
            Vector3 dir = new Vector3(1, -1, 1);
            dir.Normalize();
            Graphic.Lights[0].Type = LightType.Directional;
            Graphic.Lights[0].Diffuse = Color.White;
            Graphic.Lights[0].Ambient = Color.DarkGray;
            Graphic.Lights[0].Direction = dir;
            Graphic.Lights[0].Enabled = true;

            Graphic.RenderState.Lighting = true;
            Graphic.RenderState.Ambient = Color.Black;
        }
		
        void MainClass_MouseDown(object sender, MouseEventArgs e)
        {
            StartX = MouseX = e.X;
            StartY = MouseY = e.Y;
            StartZ = MouseZ = e.Y;
        }

        int StartX = 0, StartY = 0 ,StartZ = 0;
        int MouseX = 0, MouseY = 0 ,MouseZ = 0;
        float Sense = 0.5f;

        void MainClass_MouseMove(object sender, MouseEventArgs e)
        {
            MouseX = e.X;
            MouseY = e.Y;
            MouseZ = e.Y;
            int MovementX = MouseX - StartX;
            int MovementY = MouseY - StartY;
            int MovementZ = MouseZ - StartZ;

            if (e.Button == MouseButtons.Right)
            {
                MovementY = -MovementY;
                cam.RotateTargetYaw(Sense * MovementX);
                cam.RotateTargetPitch(Sense * MovementY);

                StartX = e.X;
                StartY = e.Y;
                MovementY = -MovementY;
            }

            if (e.Button == MouseButtons.Left)
            {
                cam.RotatePosYaw(Sense * MovementX);
                cam.RotatePosPitch(Sense * MovementY);

                StartX = e.X;
                StartY = e.Y;
            }
            if (e.Button == MouseButtons.Middle)
            {
                cam.ZoomForward(Sense * MovementZ);

                StartZ = e.Y;
            }
        }

        void MainClass_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Escape:
                    this.Close();
                    break;

                case Keys.F:
                    if (Graphic.RenderState.FillMode == FillMode.Solid)
                        Graphic.RenderState.FillMode = FillMode.WireFrame;
                    else Graphic.RenderState.FillMode = FillMode.Solid;
                    break;

                case Keys.W:
                    cam.MoveForward(0.1f);
                    break;

                case Keys.S:
                    cam.MoveForward(-0.1f);
                    break;
                case Keys.A:
                    cam.MoveRight(0.1f);
                    break;

                case Keys.D:
                    cam.MoveRight(-0.1f);
                    break;

            }
        }

        void Graphic_DeviceResizing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
        }

        void HUD()
        {
            string str = "Targrt X:" + cam.Target.X + " Y:" + cam.Target.Y + " Z:" + cam.Target.Z +
                "\nPosition X:" + cam.Position.X + " Y:" + cam.Position.Y + " Z:" + cam.Position.Z;
            font.DrawText(null, str, new Point(10, 10), Color.White);
        }
        void Render()
        {

            Graphic.Clear(ClearFlags.Target | ClearFlags.ZBuffer, Color.Purple, 1F, 1);
            Graphic.BeginScene();
            HUD();
            cam.Render(Graphic);
            Graphic.RenderState.Lighting = false;
            ground.Render(Graphic);
            Graphic.RenderState.Lighting = true;

            spaceship.Render();
            
            Graphic.EndScene();
            Graphic.Present();
        }


        //////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////
        void Frame()
        {
        }


        [STAThread]
        public static void Main()
        {
            using (MainClass frm = new MainClass())
            {
                frm.Init();
                frm.InitGeometry();
                frm.Show();
                while (frm.Created)
                {
                    frm.Frame();
                    frm.Render();
                    Application.DoEvents();
                }
            }
        }
    }
}
